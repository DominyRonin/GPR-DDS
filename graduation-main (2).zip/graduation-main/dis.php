<?php
include "DBHelper.php";
      $db=new DBHelper();
$conn=$db->connect();
$sql=" Update users SET status = 'Declined' where id='$_GET[id]' ";

if( mysqli_query($conn,$sql))
header("refresh:1; url=ApproveView.php");
    ?>