<?php 
 $_SESSION["ID"]=1;

 $_SESSION["Type"]=2;

//$_SESSION['isApproved'];
?>