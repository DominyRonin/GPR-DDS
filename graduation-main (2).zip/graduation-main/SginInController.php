<?php

//include("resview.php");
require_once("Controller.php");


class SginInController extends Controller
{
   

  

   

   function Login()
   {
      //7t 7aga al s7
      $email1=$_REQUEST['email'];
      $Pass1=$_REQUEST['password'];
     

      $this->model->Login($email1, $Pass1);
   }

   
    
}




?>
