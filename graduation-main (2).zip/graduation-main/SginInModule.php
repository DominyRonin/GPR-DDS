<?php
//include_once "login.php";
require_once("Model.php");
session_start();
include_once ("Sessions.php");
class SginInModule extends Model {

      function Login($email1, $Pass1)
      {


        //toDO 7ot login 3dl
            $db=new DBHelper(); 
            

            $result = $db->connect()->query("SELECT * FROM credentials WHERE Email = '$email1' and Password='$Pass1' ");
           
            while ($row_users =mysqli_fetch_assoc($result)) {

              $_SESSION["ID"]=$row_users['UserID'];

              $_SESSION["Type"]=$row_users['Type'];

  
            }
        
            var_dump($_SESSION["Type"]);
            var_dump($_SESSION["ID"]);




            
             







            /* dh rest pass
            if ($result2) {
                $db2=new DBHelper(); 
                $sql=" Update  users set `Password` = '$Pass2' WHERE ID='$_SESSION[ID]' ";
                $db2->connect()->query($sql);
                
          */
}   
}
 



?>