<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>GPR CUT</title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/hero-slider.css">
        <link rel="stylesheet" href="css/owl-carousel.css">
        <link rel="stylesheet" href="css/datepicker.css">
        <link rel="stylesheet" href="css/templatemo-style.css">

        <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>

<style>
body{
          background-color: #F2F2F2;
        }

</style>
    </head>
<body>

<?php

include("menu.php");
?>



    <section class="banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="banner-caption">
                      
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

    <section class="popular-places" id="popular">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <span>Our Experts and Admins</span>
                    </div>
                </div>
            </div>
            <div class="owl-carousel owl-theme">
                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>
                <div class="item popular-item">
                    <div class="thumb">
                    <img src="img1/SS.png"  alt="">
                    <h4><p style="color:Black"> Sensors Software</h4>
                            <span><p style="color:Black">2 GPR experts</span>
                        <div class="text-content">
                            
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>

                <div class="item popular-item">
                    <div class="thumb">
                        <img src="img1/logoCon.png"  alt="">
                        <div class="text-content">
                            <h4>  <p style="color:Black">The constructor</h4>
                            <span> <p style="color:Black">3 GPR experts</span>
                        </div>

                    </div>
                </div>
               
            </div>
        </div>
    </section>



    <section class="featured-places" id="blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <span>News</span>
                        <h2>What are the next updates for our software</h2>
                    </div>
                </div>
            </div>


        <!--  hna al news  <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                            <img src="img/featured_item_1.jpg" alt="">
                            <div class="overlay-content">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                            <div class="date-content">
                                <h6>28</h6>
                                <span>August</span>
                            </div>
                        </div>
                        <div class="down-content">
                            <h4>Lorem ipsum dolor</h4>
                            <span>Category One</span>
                            <p>Vestibulum id est eu felis vulputate hendrerit. Suspendisse dapibus turpis in dui pulvinar imperdiet. Nunc consectetur.</p>
                            <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                            <img src="img/featured_item_2.jpg" alt="">
                            <div class="overlay-content">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                            <div class="date-content">
                                <h6>20</h6>
                                <span>September</span>
                            </div>
                        </div>
                        <div class="down-content">
                            <h4>Nullam nibh lacus</h4>
                            <span>Category Two</span>
                            <p>Mauris sit amet quam congue, pulvinar urna et, congue diam. Suspendisse eu lorem massa. Integer sit amet posuere.</p>
                            <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                            <img src="img/featured_item_3.jpg" alt="">
                            <div class="overlay-content">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                            <div class="date-content">
                                <h6>12</h6>
                                <span>October</span>
                            </div>
                        </div>
                        <div class="down-content">
                            <h4>Suspendisse semper non</h4>
                            <span>Category Three</span>
                            <p>Praesent iaculis gravida elementum. Proin fermentum neque facilisis semper pharetra. Sed vestibulum vehicula tincidunt.</p>
                            <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
    </section>



    <section class="our-services" id="services">
        <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="section-heading">
                      <span>About Defects</span>
                  </div>
              </div>
          </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="down-services">
                        <div class="row">
                            <div class="col-md-5 col-md-offset-1">
                                <div class="left-content">
                                    <h4>About this website</h4>
                                    <p>This website is created by MIU (Graduate Students), the aim of this website to make any holder of a GPR device to be able to determine the defects that are read by the device and give an accurate result of the defects that may be inside a biller concrete slab . <br> note: that the recorded images have to be a B-scan images . </p>
                                   
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="accordions">
                                    <ul class="accordion">
                                        <li>
                                            <a>Voids Under Reinforced Concrete Slab</a>
                                            <p>Theory: Reflection Strength <br>Application Difficulty: Medium <br>Best Practices: Scan large area, analysis <br>Software: LineView, SliceView, Interpretation module
                                            <br>The size of a void and its proximity to rebar are the main factors for determining whether you
                                            can detect voids. Most commonly, people want to locate voids beneath a slab-on-grade to pre-
                                            vent a possible slab collapse if it is heavily loaded. Conquest cannot measure “honeycombing”
                                            voids in concrete.
                                            <br>GPR can detect voids beneath a slab-on-grade because there is a change in reflectivity com-
                                            pared to the normal gravel base. An empty void reflects better than the concrete-gravel inter-
                                            face, and a water-filled void reflects even better.
                                            It is unlikely you will be able to measure the thickness of a void, just the extent of its area.</p>
                                        </li>
                                        <li>
                                            <a>Corroded Rebar In Concrete</a>
                                            <p>Theory: Penetration (interference) <br>Application Difficulty: Easy<br>Best Practices: Grid Scan
                                            <br>Software: ConquestView <br>Conduits beneath rebar can be difficult to detect.
                                            <br>1. After collecting a grid over an area, carefully review the plan map images and raw data lines.
                                            <br>2. In ConquestView, scroll through the data lines to search for subtle changes. If the conduit has current flowing through it, then using the PCD response may help (see the Power Cable Detector case study).</p>
                                        </li>
                                        <li>
                                            <a>Vertical Joints Between Subsurface Concrete Slabs</a>
                                            <p>You need to fill it with something that's flexible. When installing a new slab against an existing one, many concrete masons put expansion joint material between the two slabs. Asphalt-saturated fiberboard was the staple expansion joint material of choice for years.</p>
                                        </li>
                                    </ul> <!-- / accordion -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    



    <section class="contact" id="contact">
        <div id="map">
        			<!-- How to change your own map point
                           1. Go to Google Maps
                           2. Click on your location point
                           3. Click "Share" and choose "Embed map" tab
                           4. Copy only URL and paste it within the src="" field below




                                al form msh btb3t kwys

































                    -->

                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13797.378831059943!2d31.4918564!3d30.1701457!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1b138aefe2d8bedb!2sMisr%20International%20University!5e0!3m2!1sen!2seg!4v1608136741504!5m2!1sen!2seg" width="1500" height="500" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <div class="wrapper">
                  <div class="section-heading">
                      <span>Contact Us</span>
                      <h2>You can </h2>
                  </div>
                  <!-- Modal button -->
                  <button id="modBtn" class="modal-btn">Talk to us</button>
                </div>
                <div id="modal" class="modal">
                  <!-- Modal Content -->
                  <div class="modal-content">
                    <div class="close fa fa-close"></div>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="left-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-heading">
                                            <span>Talk To Us</span>
                                            <h2>Let's have a discussion</h2>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                      <fieldset>
                                        <input name="name" type="text" class="form-control" id="name" placeholder="Your name..." required="">
                                      </fieldset>
                                    </div>
                                     <div class="col-md-6">
                                      <fieldset>
                                        <input name="subject" type="text" class="form-control" id="subject" placeholder="Your email..." required="">
                                      </fieldset>
                                    </div>
                                    <div class="col-md-6">
                                      <fieldset>
                                      <label for="cars">Choose An Expert:</label>
                                            <select name="EX" id="EX">
                                                <option value="EX1">The constructor</option>
                                                <option value="EX2">Sensors and Software</option>
                                            </select>
                                            <br>
                                      </fieldset>
                                    </div> 
                                    <div class="col-md-12">
                                      <fieldset>
                                        <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required=""></textarea>
                                      </fieldset>
                                    </div>
                                    <div class="col-md-12">
                                      <fieldset>
                                        <button type="submit" name="submit" id="form-submit" class="btn btn-primary">Send Message</button>
                                      </fieldset>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="right-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content">
                                            <div class="section-heading">
                                                <span>More About Us</span>
                                                <h2>Miu Project</h2>
                                            </div>
                                            <p>For more information and explaination feel free to contact us.</p>
                                            <ul>
                                                <li><span>Address:</span><a href="https://www.miuegypt.edu.eg/">KM 28 Cairo – Ismailia Road Ahmed Orabi District, Cairo – Egypt</a></li>
                                                <li><span>Email:</span><a href="https://www.miuegypt.edu.eg/">miu@miuegypt.edu.eg</a></li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </section>


<?php
include_once("DBHelper.php");
if(isset($_POST['submit']))
{
    $email = $_POST['subject'];
      $message = $_POST['message'];
    
    $db=new DBHelper();
    $sql="INSERT INTO messages(Message,ExpertID,Reply,Sender) VALUES ('$message','5','','$email')";;
    var_dump($sql);
    
  $result = $db->connect()->query($sql);;
    if($result)	
    {
     echo "<script>
      alert('Submitted successfully');
       window.location.href='index.php';
      </script>";
    }


}



include("footer.php");
?>

    <div class="sub-footer">
        <p>Copyright &copy; 2018 Company Name

    	- Design: <a rel="nofollow" href="http://www.templatemo.com">Template Mo</a></p>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js" type="text/javascript"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="js/vendor/bootstrap.min.js"></script>

    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
