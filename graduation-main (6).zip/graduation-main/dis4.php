<?php
include "DBHelper.php";
      $db=new DBHelper();
$conn=$db->connect();
$sql=" Delete from messages where ID ='$_GET[id]' ";

if( mysqli_query($conn,$sql))
header("refresh:1; url=AdminMessageView.php");
    ?>