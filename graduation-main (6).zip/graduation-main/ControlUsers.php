<html>

<head>


    
        <!-- Theme Style -->
        <link rel="stylesheet" href="css/style.css">
      </head>



<body>
     
<?php include ("menu.php");?>
<section class="container">

  <div class="column">
    <div class="card" style="width: 18rem;">
  <img src="img1/1200px-OOjs_UI_icon_add.svg.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Add New Expert</h5>
    <p class="card-text">You can add approved doctor from here</p>
    <a href="AddExpertView.php" class="btn btn-primary">Add</a>
  </div>
</div>
  </div>
    <hr>
  <div class="column">
    <div class="card" style="width: 18rem;">
  <img src="img1/subtract8-512.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Delete Users</h5>
    <p class="card-text">Delete any Doctor you want </p>
    <a href="DeleteuserView.php" class="btn btn-primary">Delete</a>
  </div>
</div> 
  </div>
     <hr>
  <!--<div class="column">
    <div class="card" style="width: 18rem;">
  <img src="img1/refresh+reload+update+icon-1320191166843452904.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Update Users</h5>
    <p class="card-text">you can update doctor info here</p>
    <a href="EditUserView.php" class="btn btn-primary">Update</a>
  </div>
</div>
  </div>
-->

   </section> 
</body>
    


</html>