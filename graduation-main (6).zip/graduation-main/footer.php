<html>
<head>
</head>
<body>
<footer style="background-color: white;">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-veno">
                        <div class="logo">
                            <img src="img1/footer_logo.png" width="150" height="150" >
                        </div>
                        <ul class="social-icons">
                            <li>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-rss"></i></a>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="useful-links">
                        <div class="footer-heading">
                           
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="contact-info">
                        <div class="footer-heading">
                            <h4>Contact Information</h4>
                        </div>
                        <p>For more information please contact us at .</p>
                        <ul>
                            <li><span>Address:</span><a href="https://www.miuegypt.edu.eg/">KM 28 Cairo – Ismailia Road Ahmed Orabi District, Cairo – Egypt</a></li>
                            <li><span>Email:</span><a href="https://www.miuegypt.edu.eg/">miu@miuegypt.edu.eg</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>
