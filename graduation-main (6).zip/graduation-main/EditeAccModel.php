<?php
if (session_status() == PHP_SESSION_NONE)
{  error_reporting(E_ALL ^ E_WARNING); 
  session_start();
}
//include_once "login.php";
require_once("Model.php");

class EditeAccModel extends Model {

      function Register($firstname,$lastname,$email,$password,$DOB )
      {
  

            include_once("DBHelper.php");
            $db=new DBHelper();
            "Update credentials set (Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('1','$email','$password','$firstname','$lastname','$DOB','Approved') WHERE UserID='$_SESSION[ID]'";
            //var_dump($sql);
            $sql="UPDATE `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
		   
            return $result;
}   

function Delete()
{


      include_once("DBHelper.php");
      $db=new DBHelper();
      $sql="DELETE credentials, clients 
      FROM credentials INNER JOIN clients
        ON credentials.UserID = clients.ID
      WHERE credentials.UserID ='$_SESSION[ID]' ";
      
        $result = $db->connect()->query($sql);
      if($result)	
      {
       echo "<script>
        alert('Delete successfully');
         window.location.href='logout.php';
        </script>";  
      }
     
      return $result;
}   
}
 



?>