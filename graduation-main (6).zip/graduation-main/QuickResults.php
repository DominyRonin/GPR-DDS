<!DOCTYPE html>
<html>
    <head>

      <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
      <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

      <link rel="stylesheet" href="css/bootstrap.min.css">
              <link rel="stylesheet" href="css/bootstrap-theme.min.css">
              <link rel="stylesheet" href="css/fontAwesome.css">
              <link rel="stylesheet" href="css/hero-slider.css">
              <link rel="stylesheet" href="css/owl-carousel.css">
              <link rel="stylesheet" href="css/datepicker.css">
              <link rel="stylesheet" href="css/templatemo-style.css">

              <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">

              <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>

      <?php
include "menu.php";
       ?>

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css"/>
      <link rel="stylesheet" href="css/style.css">

      <style>
      <?php
      include "css/gallery.css";
       ?>
      </style>
      <?php
        $msg = "";

        // If upload button is clicked ...
        if (isset($_POST['upload'])) {

          $filename = $_FILES["uploadfile"]["name"];
          $tempname = $_FILES["uploadfile"]["tmp_name"];
              $folder = "image/".$filename;

          $db = mysqli_connect("localhost", "root", "", "gpr");

              // Get all the submitted data from the form
              $sql = "INSERT INTO images (filename) VALUES ('$filename')";

              // Execute query
              mysqli_query($db, $sql);

              // Now let's move the uploaded image into the folder: image
              if (move_uploaded_file($tempname, $folder))  {
                  $msg = "Image uploaded successfully";
              }else{
                  $msg = "Failed to upload image";
            }
            $result = mysqli_query($db, "SELECT * FROM images");
        }
        
      ?>
    </head>

    <body>


                  <form action="" method="POST" enctype="multipart/form-data">
                        <label for="img">Select image:</label>
                         <input type="file" id="img" name="img" accept="image/*">
                        <input type="submit" name="upload" >
</form>
      		

      <?php
      include "footer.php";
       ?>
    </body>

    <script>
    $(document).ready(function(){

        $(".filter-button").click(function(){
            var value = $(this).attr('data-filter');

            if(value == "all")
            {
                $('.filter').show('1000');
            }
            else
            {
                $(".filter").not('.'+value).hide('3000');
                $('.filter').filter('.'+value).show('3000');

            }
    	    	});
    });
    /*	end gallery */

    $(document).ready(function(){
        $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none"
        });
    });

    var coll = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < coll.length; i++) {
      coll[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.maxHeight){
          content.style.maxHeight = null;
        } else {
          content.style.maxHeight = content.scrollHeight + "px";
        }
      });
    }
    </script>
</html>
