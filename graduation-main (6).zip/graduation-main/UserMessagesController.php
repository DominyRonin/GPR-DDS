<?php

//include("resview.php");
require_once("Controller.php");


class UserMessagesController extends Controller
{
   
   function retrivemsg()
   {
      $this->model->retrivemsg();
   }

    function sendmasseg()
    { 
       // $id = $_POST[];
        $msg = $_POST['message'];
        $this->model->retrivemsg($msg);
    }
    
}




?>
