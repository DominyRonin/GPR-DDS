<?php
if (session_status() == PHP_SESSION_NONE)
{  error_reporting(E_ALL ^ E_WARNING); 
  session_start();
}
//include_once "login.php";
require_once("Model.php");

class EditeAccModel extends Model {

      function Register($firstname,$lastname,$email,$password,$DOB )
      {
  

            include_once("DBHelper.php");
            $db=new DBHelper();
            $sql="Update credentials set (Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('2','$email','$password','$firstname','$lastname','$DOB','Approved') WHERE UserID='$_SESSION[ID]'";;
            
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
		   
            return $result;
}   

function Delete()
{


      include_once("DBHelper.php");
      $db=new DBHelper();
      $sql="Delete From credentials where UserID= '$_SESSION[ID]' ";
      
        $result = $db->connect()->query($sql);
      if($result)	
      {
       echo "<script>
        alert('Delete successfully');
         window.location.href='logout.php';
        </script>";  
      }
     
      return $result;
}   
}
 



?>