<?php
//include_once "login.php";
require_once("Model.php");

class sginupModule extends Model {

      function Register($firstname,$lastname,$email,$password,$DOB )
      {
  

            include_once("DBHelper.php");
            $db=new DBHelper();
            # $password=sha1($password);
            $sql="INSERT INTO credentials(Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('1','$email','$password','$firstname','$lastname','$DOB','pending')";;
            //var_dump($sql);
            
          $result = $db->connect()->query($sql);;
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='signinView.php';
              </script>";  
		    }
		   
            return $result;





            /* dh rest pass
            if ($result2) {
                $db2=new DBHelper(); 
                $sql=" Update  users set `Password` = '$Pass2' WHERE ID='$_SESSION[ID]' ";
                $db2->connect()->query($sql);
                
          */
}   
}
 



?>