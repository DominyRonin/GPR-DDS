<?php
class Expert extends User {
  

 

  public function Correctresults($BImageplace,$defect) : void {
    $db=new DBHelper(); 
    $BImage=$BImageplace;
    $Def=$defect;
    //the update need to be fixed
    $result = $db->connect()->query("UPDATE `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]' ");

}

  public function SendReplay($email,$msg) :void {
    
    $msg1 = wordwrap($msg,70);
    
    // send email
    mail("$email","Expert Responce",$msg1);
  }

  

}









?>