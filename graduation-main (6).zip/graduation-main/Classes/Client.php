<?php
class Client extends User {
  public $IsDeleted;
  public $Pillars=[];




 public function Set_Deleted($Delete) {
    $this->IsDeleted = $Delete;
 }

 public function Set_pillar($Pillar) {
    $this->Pillars = $Pillar;
 }


 

  public function Get_delet() {
    return $this->IsDeleted;
  }
  public function get_pillar() {
    return $this->Pillars;
  }

  

  public function Delete($id) :void {
    //delete  pillar
  }

  public function addimage($images, $pillarID) :void {
    //addnew images with pillar id   pillar
  }
  public function AddPillar($SecNum) :void
  {

            include_once("DBHelper.php");
            $db=new DBHelper();
            //make new add 
            $sql="UPDATE `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
  }


  public function pillarsize  ( $Size) :void
  {
    $email1 = $email ;
    $message = $msg;
  
  //add new size
  $sql="INSERT INTO messages(Message,ExpertID,Reply,Sender) VALUES ('$message','5','','$email1')";;
  var_dump($sql);
  
$result = $db->connect()->query($sql);;
  if($result)	
  {
   echo "<script>
    alert('Submitted successfully');
     window.location.href='index.php';
    </script>";
  }
  }

}









?>