<?php
class Admin extends User {
  

 

    public function AddUser($fname,$lname,$email,$password,$Id) :void
    {
  
              include_once("DBHelper.php");
              $db=new DBHelper();
              "insert credentials set (Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('1','$email','$password','$firstname','$lastname','$DOB','Approved') WHERE UserID='$_SESSION[ID]'";
              //var_dump($sql);
              $sql="insertinto `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
                $result = $db->connect()->query($sql);
              if($result)	
              {
               echo "<script>
                alert('Submitted successfully');
                 window.location.href='EditeAccView.php';
                </script>";  
              }
    }

    public function Updateuser($fname,$lname,$email,$password,$id) :void
  {

            include_once("DBHelper.php");
            $db=new DBHelper();
            "Update credentials set (Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('1','$email','$password','$firstname','$lastname','$DOB','Approved') WHERE UserID='$_SESSION[ID]'";
            //var_dump($sql);
            $sql="UPDATE `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
  }

  public function Deleteuser($email,$id) :void
  {

            include_once("DBHelper.php");
            $db=new DBHelper();
            
            $sql="Delete `credentials` WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
  }
  public function SendReplay($email,$msg) :void {
    
    $msg1 = wordwrap($msg,70);
    
    // send email
    mail("$email","Expert Responce",$msg1);
  }

  

}









?>