<?php
class User {
  public $ID;
  public $FName;
  public $LName;
  public $Email;
  public $Password;
  public $TypeID;

  function __construct($FName,$LName,$Email,$Password , $TypeID) {
    $this->FName = $FName;
    $this->LName = $LName;
    $this->Email = $Email;
    $this->Password = $Password;
    $this->TypeID = $TypeID;
  }

  public function set_Fname($FName) {
     $this->FName=$FName;
  }

  public  function set_Lname($LName) {
    $this->LName = $LName;
 }

 public function set_Email($Email) {
    $this->Email = $Email;
 }

 public function set_Pass($Password) {
    $this->Password = $Password;
 }

 public function set_Type($TypeID) {
    $this->TypeID = $TypeID;
 }


 public function get_Fname() {
    return $this->FName;
  }

  public function get_Lname() {
    return  $this->LName;
  }
  public function get_Email() {
    return  $this->Email;
  }
  public function get_Pass() {
    return $this->Password;
  }
  public function get_Type() {
    return $this->TypeID;
  }

  public function LogIN($email,$password) : void {/*
    $db=new DBHelper(); 
    $email1=$email;
    $Pass1=$password;
    $result = $db->connect()->query("SELECT * FROM credentials WHERE Email = '$email1' and Password='$Pass1' ");
    if (session_status() == PHP_SESSION_NONE)
    {  error_reporting(E_ALL ^ E_WARNING); 
      session_start();
    }
    while ($row_users =mysqli_fetch_assoc($result)) {
      $_SESSION['ID']=$row_users['UserID'];             
      $_SESSION['Type']=$row_users['Type'];
      $_SESSION['Email']=$row_users['Email'];       
      $_SESSION['State']=$row_users['status'];
     */
  }

  public function LogOut() :void {
    session_unset();

    // destroy the session
    session_destroy();
    header('location:index.php');
    exit;
  }

  public function Update($fname,$lname,$email,$password) :void
  {

            include_once("DBHelper.php");
            $db=new DBHelper();
            "Update credentials set (Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('1','$email','$password','$firstname','$lastname','$DOB','Approved') WHERE UserID='$_SESSION[ID]'";
            //var_dump($sql);
            $sql="UPDATE `credentials` SET `Type` = '1', `Email` = '$email', `Password` = '$password', `FirstName` = '$firstname', `LastName` = '$lastname', `DOB` = '$DOB', `status` = 'Approved' WHERE `credentials`.`UserID` = '$_SESSION[ID]' AND `credentials`.`Email` = '$_SESSION[Email]'";
              $result = $db->connect()->query($sql);
            if($result)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='EditeAccView.php';
              </script>";  
		    }
  }


  public function msgsend  ( $msg ,$email) :void
  {
    $email1 = $email ;
    $message = $msg;
  
  $db=new DBHelper();
  $sql="INSERT INTO messages(Message,ExpertID,Reply,Sender) VALUES ('$message','5','','$email1')";;
  var_dump($sql);
  
$result = $db->connect()->query($sql);;
  if($result)	
  {
   echo "<script>
    alert('Submitted successfully');
     window.location.href='index.php';
    </script>";
  }
  }

}









?>