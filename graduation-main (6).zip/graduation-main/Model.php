<?php
include_once("DBHelper.php");
abstract class Model{

   
}


?>