<?php
//include_once "login.php";
require_once("Model.php");

class AddExpertModule extends Model {

      function Register($firstname,$lastname,$email,$password,$DOB,$Association )
      {
  

            include_once("DBHelper.php");
            $db=new DBHelper();
            $sql="INSERT INTO credentials(Type,Email,Password,FirstName,LastName,DOB,status) VALUES ('2','$email','$password','$firstname','$lastname','$DOB','Approved')";;
            $result = $db->connect()->query($sql);

            $sql2="SELECT UserID FROM credentials ORDER BY UserID DESC LIMIT 1";
            $result3 = $db->connect()->query($sql2);
            var_dump ( $result3);
            while($row=mysqli_fetch_array($result3)){
                  $ID=$row[0];
            }
            echo $ID;
            $sql1="INSERT INTO experts VALUES ('$ID','$Association','0')";;
            $result2 = $db->connect()->query($sql1);
            
            if($result && $result2)	
		    {
			 echo "<script>
              alert('Submitted successfully');
               window.location.href='AddExpertView.php';
              </script>";  
		    }
		   
            return $result;




            
             







            /* dh rest pass
            if ($result2) {
                $db2=new DBHelper(); 
                $sql=" Update  users set `Password` = '$Pass2' WHERE ID='$_SESSION[ID]' ";
                $db2->connect()->query($sql);
                
          */
}   
}
 



?>