<?php

require_once("Model.php");
class AdminMessageModel extends Model {
    private $data;

      function AddDefect($Name, $Discription){
       
         $db=new DBHelper(); 
         $sql="INSERT INTO `messages` (`Message`,`Reply`, `Sender`) VALUES ('$Discription','','$Name');";
         //var_dump ($sql);
         $this->data=$db->connect()->query($sql);
     
       }
       function retriveDefcts(){
       
        $db=new DBHelper(); 
        $sql="Select * from messages ";
        $this->data=$db->connect()->query($sql);
        return  $this->data ;
    
      }
 

       function deleteDefect($id){

        $db=new DBHelper(); 
        $sql=" Delete From messages where id='$id'";
        $result=$db->connect()->query($sql);
       }

}

?>