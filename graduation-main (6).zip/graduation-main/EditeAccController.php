<?php

//include("resview.php");
require_once("Controller.php");


class EditeAccController extends Controller
{
   

  

   

   function Register()
   {
      //7t 7aga al s7
      $firstname = $_POST['fname'];
      $lastname = $_POST['lname'];
      $email = $_POST['email'];
      $password = $_POST['Password'];
      $DOB=$_POST["date"];

      $this->model->Register($firstname,$lastname,$email,$password,$DOB);
   }

   function Delete()
   {
      //7t 7aga al s7

      $this->model->Delete();
   }
    
}




?>
