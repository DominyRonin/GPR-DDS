<?php

require_once("Model.php");
class UserMessagesModel extends Model {
private $data;
  
function getuser()
{
    return $this->data;
}

      function retrivemsg(){
       
         $db=new DBHelper(); 
         $sql="Select * from messages Where Reply = '' ";
         $this->data=$db->connect()->query($sql);
     
       }
 

       function sendmasseg($msg){
            //send e mail

       }

}

?>