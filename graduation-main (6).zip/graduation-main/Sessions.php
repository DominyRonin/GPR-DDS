<?php 
/*if (session_status() == PHP_SESSION_NONE)
{  error_reporting(E_ALL ^ E_WARNING); 
  session_start();
}*/
 //$_SESSION["ID"];

// $_SESSION["Type"];
//$_SESSION['isApproved'];
?>