<?php
if (session_status() == PHP_SESSION_NONE)
{  error_reporting(E_ALL ^ E_WARNING); 
  session_start();
}

//include_once "login.php";
require_once("Model.php");
class EditePasswordModel extends Model {

      function savePass($Pass1, $Pass2)
      {
            $db=new DBHelper(); 
            
            $result2 = $db->connect()->query("SELECT * FROM credentials WHERE Password = '$Pass1' and UserID='$_SESSION[ID]' ");
            if ($result2) {
                $db2=new DBHelper(); 
                $sql=" Update  credentials set `Password` = '$Pass2' WHERE UserID='$_SESSION[ID]' ";
                $db2->connect()->query($sql);
                
          
}   
}
 

}

?>